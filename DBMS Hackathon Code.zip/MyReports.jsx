import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, ClipboardList, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { campusApi } from '@/api/campus';
import PageHeader from '@/components/PageHeader';
import StateBlock from '@/components/StateBlock';
import SeverityBadge from '@/components/incidents/SeverityBadge';
import StatusBadge from '@/components/incidents/StatusBadge';
import IncidentDetailSheet from '@/components/incidents/IncidentDetailSheet';
import { SAFETY_NOTICE } from '@/lib/constants';
import { fmtDuration, timeAgo } from '@/lib/format';

export default function MyReports() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await campusApi.incidents('list', { filters: {}, sort: 'recent', limit: 50 });
      setRows(data.items || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const open = rows.filter((r) => r.status !== 'RESOLVED');
  const resolved = rows.filter((r) => r.status === 'RESOLVED');

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Student / reporter"
        title="My reports"
        description="Every emergency you have reported, with its live status, response team and resolution details."
        actions={
          <Button asChild className="h-10 rounded-xl">
            <Link to="/report"><Plus className="mr-1.5 h-4 w-4" /> Report emergency</Link>
          </Button>
        }
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl bg-card p-4 ring-1 ring-border">
          <p className="text-[10.5px] font-medium uppercase tracking-[0.11em] text-muted-foreground">Open reports</p>
          <p className="num mt-2 font-display text-[30px] leading-none text-[hsl(216_58%_22%)]">{open.length}</p>
        </div>
        <div className="rounded-2xl bg-card p-4 ring-1 ring-border">
          <p className="text-[10.5px] font-medium uppercase tracking-[0.11em] text-muted-foreground">Resolved</p>
          <p className="num mt-2 font-display text-[30px] leading-none text-emerald-700">{resolved.length}</p>
        </div>
        <div className="rounded-2xl bg-card p-4 ring-1 ring-border">
          <p className="text-[10.5px] font-medium uppercase tracking-[0.11em] text-muted-foreground">Total submitted</p>
          <p className="num mt-2 font-display text-[30px] leading-none">{rows.length}</p>
        </div>
      </div>

      <div className="rounded-2xl bg-card ring-1 ring-border">
        <div className="border-b border-border px-4 py-3">
          <p className="text-xs font-medium">Report history</p>
        </div>

        {loading ? (
          <StateBlock variant="loading" />
        ) : error ? (
          <StateBlock variant="error" title="Could not load your reports" description={error} actionLabel="Try again" onAction={load} />
        ) : rows.length === 0 ? (
          <StateBlock
            title="You have not reported anything yet"
            description="When you submit an emergency report it appears here with its status and the team handling it."
            actionLabel="Report an emergency"
            onAction={() => { window.location.href = '/report'; }}
          />
        ) : (
          <div className="divide-y divide-border">
            {rows.map((incident) => (
              <button
                key={incident.id}
                onClick={() => setSelected(incident.id)}
                className="flex w-full items-start gap-3 px-4 py-3.5 text-left transition-colors hover:bg-secondary/60"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-mono text-[11px] text-muted-foreground">{incident.incident_code}</span>
                    <SeverityBadge severity={incident.final_severity} size="sm" />
                    <StatusBadge status={incident.status} size="sm" />
                  </div>
                  <p className="mt-1.5 truncate text-sm font-medium">{incident.title}</p>
                  <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
                    {incident.location_name} · {timeAgo(incident.reported_at)}
                    {incident.assignee_summary ? ` · ${incident.assignee_summary}` : ''}
                    {incident.status === 'RESOLVED' ? ` · resolved in ${fmtDuration(incident.resolution_minutes)}` : ''}
                  </p>
                </div>
                <ArrowUpRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        )}
      </div>

      <p className="flex items-start gap-2 rounded-xl bg-secondary/60 px-4 py-3 text-[11px] leading-relaxed text-muted-foreground">
        <ClipboardList className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {SAFETY_NOTICE}
      </p>

      <IncidentDetailSheet
        incidentId={selected}
        open={Boolean(selected)}
        onOpenChange={(v) => { if (!v) setSelected(null); }}
        onChanged={load}
      />
    </div>
  );
}