import { useCallback, useEffect, useState } from 'react';
import { ArrowUpRight, Radio } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { campusApi } from '@/api/campus';
import useSession from '@/hooks/useSession';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import StateBlock from '@/components/StateBlock';
import SeverityBadge from '@/components/incidents/SeverityBadge';
import StatusBadge from '@/components/incidents/StatusBadge';
import IncidentDetailSheet from '@/components/incidents/IncidentDetailSheet';
import { AVAILABILITY_LABEL } from '@/lib/constants';
import { timeAgo } from '@/lib/format';

export default function ResponderDashboard() {
  const { responder, refresh, user } = useSession();
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await campusApi.incidents('list', { filters: {}, sort: 'priority', limit: 50 });
      setRows(data.items || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const setAvailability = async (availability) => {
    try {
      await campusApi.responders('update_availability', { id: responder.id, availability });
      toast({ title: `Availability set to ${AVAILABILITY_LABEL[availability].toLowerCase()}` });
      refresh();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Could not update availability', description: err.message });
    }
  };

  const active = rows.filter((r) => r.status !== 'RESOLVED');
  const done = rows.filter((r) => r.status === 'RESOLVED');

  if (!responder) {
    return (
      <div className="space-y-6">
        <PageHeader eyebrow="Responder console" title="My assignments" description="This console is for campus responders." />
        <div className="rounded-2xl bg-card ring-1 ring-border">
          <StateBlock
            title="No responder unit is linked to your account"
            description="An administrator links a responder unit to your login email from the Responders page. Administrators use the dashboard instead."
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Responder console"
        title="My assignments"
        description={`Incidents assigned to ${responder?.name || user?.full_name || 'you'}${responder?.team ? ` · ${responder.team}` : ''}.`}
        actions={
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase tracking-[0.1em] text-muted-foreground">Availability</span>
            <Select value={responder?.availability || 'available'} onValueChange={setAvailability}>
              <SelectTrigger className="h-9 w-[136px] rounded-lg bg-card"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="available">Available</SelectItem>
                <SelectItem value="on_duty">On duty</SelectItem>
                <SelectItem value="off_duty">Off duty</SelectItem>
              </SelectContent>
            </Select>
          </div>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <StatCard label="Active assignments" value={active.length} tone="navy" hint="assigned, acknowledged or in progress" />
        <StatCard label="Critical among them" value={active.filter((r) => r.final_severity === 'CRITICAL').length} tone="danger" ring="ring-red-200" hint="respond immediately" />
        <StatCard label="Completed" value={done.length} tone="success" hint="resolved with a summary" />
      </div>

      <div className="rounded-2xl bg-card ring-1 ring-border">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="text-xs font-medium">Incident queue</p>
          <span className="text-[11px] text-muted-foreground">{active.length} active</span>
        </div>

        {loading ? (
          <StateBlock variant="loading" />
        ) : error ? (
          <StateBlock variant="error" title="Could not load assignments" description={error} actionLabel="Try again" onAction={load} />
        ) : rows.length === 0 ? (
          <StateBlock
            title="No incidents assigned to you"
            description="When the control desk assigns you an incident it will appear here with its severity and location."
          />
        ) : (
          <div className="divide-y divide-border">
            {rows.map((incident) => (
              <button
                key={incident.id}
                onClick={() => setSelected(incident.id)}
                className="flex w-full items-start gap-3 px-4 py-3.5 text-left transition-colors hover:bg-secondary/60"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-mono text-[11px] text-muted-foreground">{incident.incident_code}</span>
                    <SeverityBadge severity={incident.final_severity} size="sm" />
                    <StatusBadge status={incident.status} size="sm" />
                  </div>
                  <p className="mt-1.5 truncate text-sm font-medium">{incident.title}</p>
                  <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
                    {incident.location_name} · {incident.building} · {timeAgo(incident.reported_at)}
                  </p>
                </div>
                <ArrowUpRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        )}
      </div>

      <p className="flex items-start gap-2 rounded-xl bg-secondary/60 px-4 py-3 text-[11px] leading-relaxed text-muted-foreground">
        <Radio className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        Acknowledge an assignment as soon as you receive it, then move the incident to In progress and record a resolution
        summary when the situation is handled.
      </p>

      <IncidentDetailSheet
        incidentId={selected}
        open={Boolean(selected)}
        onOpenChange={(v) => { if (!v) setSelected(null); }}
        onChanged={load}
      />
    </div>
  );
}