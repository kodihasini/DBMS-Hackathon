import { Navigate } from 'react-router-dom';
import useSession from '@/hooks/useSession';

export default function Home() {
  const { role, loading } = useSession();

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-7 w-7 animate-spin rounded-full border-[3px] border-slate-200 border-t-slate-800" />
      </div>
    );
  }

  if (role === 'administrator') return <Navigate to="/admin" replace />;
  if (role === 'responder') return <Navigate to="/responder" replace />;
  return <Navigate to="/my-reports" replace />;
}