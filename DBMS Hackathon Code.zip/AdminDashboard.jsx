import { useCallback, useEffect, useState } from 'react';
import { ArrowUpRight, ChevronLeft, ChevronRight, Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { campusApi } from '@/api/campus';
import useSession from '@/hooks/useSession';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import StateBlock from '@/components/StateBlock';
import SeverityBadge from '@/components/incidents/SeverityBadge';
import StatusBadge from '@/components/incidents/StatusBadge';
import IncidentDetailSheet from '@/components/incidents/IncidentDetailSheet';
import NotificationQueue from '@/components/incidents/NotificationQueue';
import SafetyTrends from '@/components/dashboard/SafetyTrends';
import { CATEGORIES } from '@/lib/constants';
import { ageInHours, fmtDuration, timeAgo } from '@/lib/format';

const PAGE_SIZE = 20;

export default function AdminDashboard() {
  const { user } = useSession();
  const [searchInput, setSearchInput] = useState('');
  const [filters, setFilters] = useState({ search: '', severity: 'all', status: 'all', category: 'all', location_id: 'all' });
  const [sort, setSort] = useState('priority');
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [stats, setStats] = useState(null);
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setFilters((f) => ({ ...f, search: searchInput })), 350);
    return () => clearTimeout(t);
  }, [searchInput]);

  const loadStats = useCallback(async () => {
    try {
      setStats(await campusApi.stats());
    } catch (err) {
      setError(err.message);
    }
  }, []);

  const loadList = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await campusApi.incidents('list', { filters, sort, page, limit: PAGE_SIZE });
      setRows(data.items || []);
      setTotal(data.total || 0);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [filters, sort, page]);

  useEffect(() => { loadList(); }, [loadList]);
  useEffect(() => { loadStats(); campusApi.locations('list').then((d) => setLocations(d.items || [])); }, [loadStats]);

  const refreshAll = () => { loadList(); loadStats(); };
  const setFilter = (key, value) => { setPage(1); setFilters((f) => ({ ...f, [key]: value })); };

  const totals = stats?.totals;

  return (
    <div className="space-y-7">
      <PageHeader
        eyebrow="Administrator console"
        title="Emergency overview"
        description={`Live incident queue${user?.full_name ? ` for ${user.full_name}` : ''}. Suggested severity, responder assignment and resolution history — all from live records.`}
        actions={
          <div className="rounded-xl bg-card px-3 py-2 text-right ring-1 ring-border">
            <p className="num font-display text-lg leading-none">{fmtDuration(stats?.avg_resolution_minutes)}</p>
            <p className="text-[10px] uppercase tracking-[0.1em] text-muted-foreground">Avg. resolution</p>
          </div>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard label="Total incidents" value={totals?.incidents ?? '—'} hint="all reports on record" />
        <StatCard label="Open incidents" value={totals?.open ?? '—'} hint="reported, assigned or in progress" tone="navy" />
        <StatCard label="Critical open" value={totals?.critical_open ?? '—'} tone="danger" ring="ring-red-200" hint="needs attention now" />
        <StatCard label="Resolved" value={totals?.resolved ?? '—'} tone="success" hint="closed with a summary" />
        <StatCard label="Available responders" value={totals?.available_responders ?? '—'} hint={`${totals?.on_duty_responders ?? 0} on duty`} />
      </div>

      {stats?.oldest_open ? (
        <div className="flex flex-wrap items-center gap-2 rounded-xl bg-amber-50/70 px-4 py-2.5 text-[11.5px] text-amber-900 ring-1 ring-amber-200">
          <span className="font-medium">Longest waiting open incident:</span>
          <span>{stats.oldest_open.incident_code} · {stats.oldest_open.title}</span>
          <span className="num rounded-full bg-white px-2 py-0.5 font-medium ring-1 ring-amber-200">
            {Math.round(stats.oldest_open.age_hours)} h open
          </span>
        </div>
      ) : null}

      <SafetyTrends stats={stats} />

      <div className="grid gap-6 xl:grid-cols-[1fr_340px]">
        <div className="min-w-0 rounded-2xl bg-card ring-1 ring-border">
          <div className="space-y-3 border-b border-border p-4">
            <div className="flex min-w-0 flex-col gap-2 sm:flex-row">
              <div className="relative min-w-0 flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder="Search incident, code, location…"
                  className="h-9 rounded-lg pl-9"
                />
              </div>
              <Select value={sort} onValueChange={(v) => { setSort(v); setPage(1); }}>
                <SelectTrigger className="h-9 w-[152px] rounded-lg">
                  <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="priority">Severity first</SelectItem>
                  <SelectItem value="recent">Most recent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid min-w-0 grid-cols-2 gap-2 sm:grid-cols-4">
              <Select value={filters.severity} onValueChange={(v) => setFilter('severity', v)}>
                <SelectTrigger className="h-8 w-full min-w-0 rounded-lg text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All severity</SelectItem>
                  <SelectItem value="CRITICAL">Critical</SelectItem>
                  <SelectItem value="HIGH">High</SelectItem>
                  <SelectItem value="MEDIUM">Medium</SelectItem>
                  <SelectItem value="LOW">Low</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filters.status} onValueChange={(v) => setFilter('status', v)}>
                <SelectTrigger className="h-8 w-full min-w-0 rounded-lg text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All status</SelectItem>
                  <SelectItem value="REPORTED">Reported</SelectItem>
                  <SelectItem value="ASSIGNED">Assigned</SelectItem>
                  <SelectItem value="IN_PROGRESS">In progress</SelectItem>
                  <SelectItem value="RESOLVED">Resolved</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filters.category} onValueChange={(v) => setFilter('category', v)}>
                <SelectTrigger className="h-8 w-full min-w-0 rounded-lg text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filters.location_id} onValueChange={(v) => setFilter('location_id', v)}>
                <SelectTrigger className="h-8 w-full min-w-0 rounded-lg text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All locations</SelectItem>
                  {locations.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {loading ? (
            <StateBlock variant="loading" />
          ) : error ? (
            <StateBlock variant="error" title="Could not load incidents" description={error} actionLabel="Try again" onAction={loadList} />
          ) : rows.length === 0 ? (
            <StateBlock
              title="No incidents match these filters"
              description="Clear a filter, or wait for the next report to come in from a student."
              actionLabel="Reset filters"
              onAction={() => { setFilters({ search: '', severity: 'all', status: 'all', category: 'all', location_id: 'all' }); setSearchInput(''); }}
            />
          ) : (
            <div className="divide-y divide-border">
              {rows.map((incident) => {
                const hours = ageInHours(incident.reported_at);
                const stale = incident.status !== 'RESOLVED' && hours > 24;
                return (
                  <button
                    key={incident.id}
                    onClick={() => setSelected(incident.id)}
                    className="flex w-full items-start gap-3 px-4 py-3.5 text-left transition-colors hover:bg-secondary/60"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-mono text-[11px] text-muted-foreground">{incident.incident_code}</span>
                        <SeverityBadge severity={incident.final_severity} size="sm" />
                        <StatusBadge status={incident.status} size="sm" />
                        {stale ? (
                          <span className="rounded-full bg-amber-50 px-1.5 py-0.5 text-[10px] font-medium text-amber-800 ring-1 ring-amber-200">
                            waiting {Math.round(hours)}h
                          </span>
                        ) : null}
                        {incident.is_demo ? (
                          <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">demo</span>
                        ) : null}
                      </div>
                      <p className="mt-1.5 truncate text-sm font-medium">{incident.title}</p>
                      <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
                        {incident.location_name} · {incident.category} · {timeAgo(incident.reported_at)}
                      </p>
                    </div>
                    <div className="hidden w-36 shrink-0 text-right sm:block">
                      <p className="truncate text-[11.5px] text-muted-foreground">{incident.assignee_summary || 'Unassigned'}</p>
                    </div>
                    <ArrowUpRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                );
              })}
            </div>
          )}

          {total > PAGE_SIZE ? (
            <div className="flex items-center justify-between border-t border-border px-4 py-2.5 text-[11px] text-muted-foreground">
              <span>{total} incidents · page {page} of {Math.ceil(total / PAGE_SIZE)}</span>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={page * PAGE_SIZE >= total} onClick={() => setPage((p) => p + 1)}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : null}
        </div>

        <NotificationQueue data={stats?.notifications} onProcessed={loadStats} />
      </div>

      <IncidentDetailSheet
        incidentId={selected}
        open={Boolean(selected)}
        onOpenChange={(v) => { if (!v) setSelected(null); }}
        onChanged={refreshAll}
      />
    </div>
  );
}