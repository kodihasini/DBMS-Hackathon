import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Camera, Check, Loader2, Siren, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { campusApi } from '@/api/campus';
import useSession from '@/hooks/useSession';
import PageHeader from '@/components/PageHeader';
import ClassificationCard from '@/components/incidents/ClassificationCard';
import { CATEGORIES, SAFETY_NOTICE } from '@/lib/constants';

const EMPTY = {
  title: '',
  description: '',
  category: '',
  location_id: '',
  building: '',
  reporter_name: '',
  reporter_email: '',
  reporter_phone: '',
  image_uri: '',
};

export default function ReportEmergency() {
  const { user } = useSession();
  const { toast } = useToast();
  const fileRef = useRef(null);
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [locations, setLocations] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [created, setCreated] = useState(null);

  useEffect(() => {
    campusApi.locations('list').then((d) => setLocations(d.items || []));
  }, []);

  useEffect(() => {
    if (user) {
      setForm((f) => ({
        ...f,
        reporter_name: f.reporter_name || user.full_name || '',
        reporter_email: f.reporter_email || user.email || '',
      }));
    }
  }, [user]);

  const set = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const pickLocation = (id) => {
    const loc = locations.find((l) => l.id === id);
    setForm((f) => ({ ...f, location_id: id, building: loc ? `${loc.building}` : '' }));
    setErrors((e) => ({ ...e, location_id: undefined }));
  };

  const uploadPhoto = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      set('image_uri', file_uri);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Upload failed', description: error.message });
    } finally {
      setUploading(false);
    }
  };

  const validate = () => {
    const next = {};
    if (form.title.trim().length < 5) next.title = 'Give the emergency a short title (at least 5 characters).';
    if (form.description.trim().length < 15) next.description = 'Describe what is happening (at least 15 characters).';
    if (!form.category) next.category = 'Choose the emergency category.';
    if (!form.location_id) next.location_id = 'Choose the campus location.';
    if (!form.reporter_name.trim()) next.reporter_name = 'Your name is required.';
    if (!form.reporter_email.trim()) next.reporter_email = 'A contact email is required.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = async (event) => {
    event.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      const data = await campusApi.incidents('create', { payload: form });
      setCreated(data);
      setForm(EMPTY);
    } catch (error) {
      setErrors(error.fields || {});
      toast({ variant: 'destructive', title: 'Report not submitted', description: error.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (created) {
    return (
      <div className="mx-auto max-w-2xl space-y-6">
        <div className="rounded-2xl bg-card p-6 ring-1 ring-border sm:p-8">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200">
            <Check className="h-5 w-5" strokeWidth={2.6} />
          </span>
          <h1 className="mt-4 font-display text-[30px] leading-tight">Report received</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Incident <span className="font-mono text-foreground">{created.incident.incident_code}</span> is now with the campus
            control desk. You can track its status under My reports.
          </p>

          <div className="mt-5">
            <ClassificationCard
              severity={created.severity.severity}
              explanation={created.severity.explanation}
              method={created.severity.method}
              needsReview={created.severity.needs_human_review}
              score={created.severity.score}
              signals={created.severity.matched_signals}
            />
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            <Button asChild className="rounded-xl">
              <Link to="/my-reports">
                Track my reports <ArrowRight className="ml-1.5 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" className="rounded-xl" onClick={() => setCreated(null)}>
              Report another emergency
            </Button>
          </div>
        </div>
        <p className="flex items-start gap-2 px-1 text-[11px] leading-relaxed text-muted-foreground">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {SAFETY_NOTICE}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Emergency reporting"
        title="Report an emergency"
        description="Describe what is happening. CampusCare suggests a severity from your description — you never have to judge it yourself."
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <form onSubmit={submit} className="space-y-5 rounded-2xl bg-card p-5 ring-1 ring-border sm:p-7">
          <div className="space-y-2">
            <Label htmlFor="title">Emergency title</Label>
            <Input
              id="title"
              value={form.title}
              onChange={(e) => set('title', e.target.value)}
              placeholder="e.g. Smoke coming from Chemistry Lab 2"
              className={errors.title ? 'border-red-400' : ''}
            />
            {errors.title ? <p className="text-xs text-red-600">{errors.title}</p> : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">What is happening?</Label>
            <Textarea
              id="description"
              rows={5}
              value={form.description}
              onChange={(e) => set('description', e.target.value)}
              placeholder="Include what you can see or hear, how many people are affected, and whether anyone is injured."
              className={errors.description ? 'border-red-400' : ''}
            />
            <p className="text-[11px] text-muted-foreground">
              {form.description.trim().length} characters · the more specific you are, the better the severity suggestion.
            </p>
            {errors.description ? <p className="text-xs text-red-600">{errors.description}</p> : null}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(v) => set('category', v)}>
                <SelectTrigger className={errors.category ? 'border-red-400' : ''}>
                  <SelectValue placeholder="Choose a category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.category ? <p className="text-xs text-red-600">{errors.category}</p> : null}
            </div>

            <div className="space-y-2">
              <Label>Campus location</Label>
              <Select value={form.location_id} onValueChange={pickLocation}>
                <SelectTrigger className={errors.location_id ? 'border-red-400' : ''}>
                  <SelectValue placeholder={locations.length ? 'Choose a location' : 'Loading locations…'} />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((l) => (
                    <SelectItem key={l.id} value={l.id}>
                      {l.name} · {l.zone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.location_id ? <p className="text-xs text-red-600">{errors.location_id}</p> : null}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="building">Building / block (optional detail)</Label>
            <Input
              id="building"
              value={form.building}
              onChange={(e) => set('building', e.target.value)}
              placeholder="e.g. Second floor, east wing"
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="reporter_name">Your name</Label>
              <Input id="reporter_name" value={form.reporter_name} onChange={(e) => set('reporter_name', e.target.value)} className={errors.reporter_name ? 'border-red-400' : ''} />
              {errors.reporter_name ? <p className="text-xs text-red-600">{errors.reporter_name}</p> : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="reporter_email">Contact email</Label>
              <Input id="reporter_email" type="email" value={form.reporter_email} onChange={(e) => set('reporter_email', e.target.value)} className={errors.reporter_email ? 'border-red-400' : ''} />
              {errors.reporter_email ? <p className="text-xs text-red-600">{errors.reporter_email}</p> : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="reporter_phone">Phone / extension</Label>
              <Input id="reporter_phone" value={form.reporter_phone} onChange={(e) => set('reporter_phone', e.target.value)} placeholder="Optional" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Photo (optional)</Label>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => uploadPhoto(e.target.files?.[0])}
            />
            {form.image_uri ? (
              <div className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-xs">
                <Check className="h-3.5 w-3.5 text-emerald-600" /> Photo attached
                <button type="button" className="ml-auto text-muted-foreground hover:text-foreground" onClick={() => set('image_uri', '')}>
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ) : (
              <Button type="button" variant="outline" className="rounded-lg" onClick={() => fileRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Camera className="mr-2 h-4 w-4" />}
                {uploading ? 'Uploading…' : 'Attach a photo'}
              </Button>
            )}
          </div>

          <Button type="submit" disabled={submitting} className="h-11 w-full rounded-xl text-sm">
            {submitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Siren className="mr-2 h-4 w-4" />}
            {submitting ? 'Submitting report…' : 'Submit emergency report'}
          </Button>
        </form>

        <aside className="space-y-4">
          <div className="rounded-2xl bg-[hsl(216_58%_15%)] p-5 text-white">
            <div className="flex items-center gap-2">
              <Siren className="h-4 w-4" />
              <p className="text-[11px] font-medium uppercase tracking-[0.16em] text-white/70">Before you submit</p>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-white/85">{SAFETY_NOTICE}</p>
            <ul className="mt-4 space-y-2 text-xs leading-relaxed text-white/70">
              <li>· Name the exact block and room if you can.</li>
              <li>· Say whether anyone is hurt or trapped.</li>
              <li>· Report from a safe distance.</li>
            </ul>
          </div>
          <div className="rounded-2xl bg-card p-5 text-xs leading-relaxed text-muted-foreground ring-1 ring-border">
            <p className="text-[11px] font-medium uppercase tracking-[0.13em] text-foreground">How severity is suggested</p>
            <p className="mt-2">
              A Python-style rule engine weighs the category against the words in your description (smoke, unconscious,
              sparking, leak…) and suggests Critical, High, Medium or Low. Staff can always override it, and every change is
              recorded in the incident history.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}