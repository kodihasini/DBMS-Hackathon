import { useCallback, useEffect, useState } from 'react';
import { Loader2, MapPin, Pencil, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { campusApi } from '@/api/campus';
import PageHeader from '@/components/PageHeader';
import StateBlock from '@/components/StateBlock';

const ZONES = ['Central Campus', 'North Campus', 'South Campus', 'East Campus', 'West Campus', 'Residential Zone'];
const BLANK = { name: '', building: '', zone: 'Central Campus', details: '', is_active: true };

export default function AdminLocations() {
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dialog, setDialog] = useState(null);
  const [form, setForm] = useState(BLANK);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await campusApi.locations('list');
      setRows(data.items || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setForm(BLANK); setDialog('create'); };
  const openEdit = (row) => {
    setForm({ name: row.name, building: row.building, zone: row.zone, details: row.details || '', is_active: row.is_active !== false });
    setDialog(row);
  };

  const save = async () => {
    setBusy(true);
    try {
      if (dialog === 'create') {
        await campusApi.locations('create', form);
        toast({ title: 'Location added' });
      } else {
        await campusApi.locations('update', { id: dialog.id, ...form });
        toast({ title: 'Location updated' });
      }
      setDialog(null);
      load();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Could not save location', description: err.message });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (row) => {
    try {
      await campusApi.locations('delete', { id: row.id });
      toast({ title: 'Location removed' });
      load();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Location not removed', description: err.message });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Campus directory"
        title="Campus locations"
        description="The location list students choose from when reporting. Locations referenced by an incident cannot be deleted — deactivate them instead."
        actions={<Button className="h-10 rounded-xl" onClick={openCreate}><Plus className="mr-1.5 h-4 w-4" /> Add location</Button>}
      />

      <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-border">
        {loading ? (
          <StateBlock variant="loading" />
        ) : error ? (
          <StateBlock variant="error" title="Could not load locations" description={error} actionLabel="Try again" onAction={load} />
        ) : rows.length === 0 ? (
          <StateBlock title="No locations yet" description="Add the blocks and zones your campus is divided into." actionLabel="Add location" onAction={openCreate} />
        ) : (
          <div className="divide-y divide-border">
            {rows.map((row) => (
              <div key={row.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{row.name}</p>
                  <p className="truncate text-[11.5px] text-muted-foreground">{row.building} · {row.zone}{row.details ? ` · ${row.details}` : ''}</p>
                </div>
                <div className="hidden w-24 text-right text-[11.5px] text-muted-foreground sm:block">
                  {row.incident_count || 0} incident{row.incident_count === 1 ? '' : 's'}
                </div>
                <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-medium ring-1 ${row.is_active === false ? 'bg-secondary text-muted-foreground ring-border' : 'bg-emerald-50 text-emerald-800 ring-emerald-200'}`}>
                  {row.is_active === false ? 'Inactive' : 'Active'}
                </span>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(row)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 text-muted-foreground hover:text-red-700"
                    disabled={Boolean(row.incident_count)}
                    onClick={() => remove(row)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={Boolean(dialog)} onOpenChange={(v) => { if (!v) setDialog(null); }}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">{dialog === 'create' ? 'Add campus location' : 'Edit location'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Location name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Central Library" />
            </div>
            <div className="space-y-1.5">
              <Label>Building / block</Label>
              <Input value={form.building} onChange={(e) => setForm({ ...form, building: e.target.value })} placeholder="e.g. Library Block · Lobby" />
            </div>
            <div className="space-y-1.5">
              <Label>Campus zone</Label>
              <Select value={form.zone} onValueChange={(v) => setForm({ ...form, zone: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ZONES.map((z) => <SelectItem key={z} value={z}>{z}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Additional details</Label>
              <Input value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} placeholder="Floor, room, access notes" />
            </div>
            <div className="flex items-center justify-between rounded-lg bg-secondary/60 px-3 py-2">
              <p className="text-xs">Available to reporters</p>
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-lg" onClick={() => setDialog(null)}>Cancel</Button>
            <Button className="rounded-lg" onClick={save} disabled={busy || !form.name || !form.building}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null} Save location
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}