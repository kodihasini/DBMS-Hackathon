import { useCallback, useEffect, useState } from 'react';
import { Loader2, Pencil, Plus, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { campusApi } from '@/api/campus';
import PageHeader from '@/components/PageHeader';
import StateBlock from '@/components/StateBlock';
import { AVAILABILITY_LABEL, TEAMS } from '@/lib/constants';

const BLANK = { name: '', team: 'Campus Security', contact: '', user_email: '', notes: '', availability: 'available', is_active: true };

const AVAILABILITY_STYLE = {
  available: 'bg-emerald-50 text-emerald-800 ring-emerald-200',
  on_duty: 'bg-blue-50 text-blue-800 ring-blue-200',
  off_duty: 'bg-secondary text-muted-foreground ring-border',
};

export default function AdminResponders() {
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dialog, setDialog] = useState(null);
  const [form, setForm] = useState(BLANK);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await campusApi.responders('list');
      setRows(data.items || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setForm(BLANK); setDialog('create'); };
  const openEdit = (row) => {
    setForm({
      name: row.name,
      team: row.team,
      contact: row.contact || '',
      user_email: row.user_email || '',
      notes: row.notes || '',
      availability: row.availability || 'available',
      is_active: row.is_active !== false,
    });
    setDialog(row);
  };

  const save = async () => {
    setBusy(true);
    try {
      if (dialog === 'create') {
        await campusApi.responders('create', form);
        toast({ title: 'Responder added' });
      } else {
        await campusApi.responders('update', { id: dialog.id, ...form });
        toast({ title: 'Responder updated' });
      }
      setDialog(null);
      load();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Could not save responder', description: err.message });
    } finally {
      setBusy(false);
    }
  };

  const setAvailability = async (row, availability) => {
    try {
      await campusApi.responders('update_availability', { id: row.id, availability });
      load();
    } catch (err) {
      toast({ variant: 'destructive', title: 'Availability not changed', description: err.message });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Campus directory"
        title="Responders"
        description="Teams the control desk can dispatch. Link a responder to an app login email so that person can sign in and work their assigned incidents."
        actions={<Button className="h-10 rounded-xl" onClick={openCreate}><Plus className="mr-1.5 h-4 w-4" /> Add responder</Button>}
      />

      <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-border">
        {loading ? (
          <StateBlock variant="loading" />
        ) : error ? (
          <StateBlock variant="error" title="Could not load responders" description={error} actionLabel="Try again" onAction={load} />
        ) : rows.length === 0 ? (
          <StateBlock title="No responders yet" description="Add the security, medical, fire safety and maintenance units your campus relies on." actionLabel="Add responder" onAction={openCreate} />
        ) : (
          <div className="divide-y divide-border">
            {rows.map((row) => (
              <div key={row.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-muted-foreground">
                  <ShieldCheck className="h-4 w-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">
                    {row.name}
                    {row.is_demo ? <span className="ml-2 rounded-full bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">demo</span> : null}
                  </p>
                  <p className="truncate text-[11.5px] text-muted-foreground">
                    {row.team}{row.contact ? ` · ${row.contact}` : ''}{row.user_email ? ` · ${row.user_email}` : ' · no login linked'}
                  </p>
                </div>
                <div className="hidden w-32 shrink-0 text-[11px] text-muted-foreground md:block">
                  {row.active_incidents?.length ? `On ${row.active_incidents.join(', ')}` : 'No active incident'}
                </div>
                <Select value={row.availability || 'available'} onValueChange={(v) => setAvailability(row, v)}>
                  <SelectTrigger className={`h-7 w-[118px] rounded-full px-2.5 text-[11px] ring-1 ${AVAILABILITY_STYLE[row.availability] || ''}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">{AVAILABILITY_LABEL.available}</SelectItem>
                    <SelectItem value="on_duty">{AVAILABILITY_LABEL.on_duty}</SelectItem>
                    <SelectItem value="off_duty">{AVAILABILITY_LABEL.off_duty}</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(row)}>
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        Demo units are labelled and use campus extensions only — no real emergency numbers are stored. Responders are marked
        on duty automatically while they hold an active assignment, and released back to available when it is resolved.
      </p>

      <Dialog open={Boolean(dialog)} onOpenChange={(v) => { if (!v) setDialog(null); }}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">{dialog === 'create' ? 'Add responder' : 'Edit responder'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Name / unit</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Campus Security — Team B" />
            </div>
            <div className="space-y-1.5">
              <Label>Team</Label>
              <Select value={form.team} onValueChange={(v) => setForm({ ...form, team: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TEAMS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Contact</Label>
                <Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} placeholder="Campus extension" />
              </div>
              <div className="space-y-1.5">
                <Label>Availability</Label>
                <Select value={form.availability} onValueChange={(v) => setForm({ ...form, availability: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="on_duty">On duty</SelectItem>
                    <SelectItem value="off_duty">Off duty</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Login email (optional)</Label>
              <Input value={form.user_email} onChange={(e) => setForm({ ...form, user_email: e.target.value })} placeholder="responder@campus.edu" />
              <p className="text-[10.5px] text-muted-foreground">When this person signs in with this email, they get the responder dashboard.</p>
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional" />
            </div>
            <div className="flex items-center justify-between rounded-lg bg-secondary/60 px-3 py-2">
              <p className="text-xs">Active in the dispatch list</p>
              <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="rounded-lg" onClick={() => setDialog(null)}>Cancel</Button>
            <Button className="rounded-lg" onClick={save} disabled={busy || !form.name}>
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null} Save responder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}